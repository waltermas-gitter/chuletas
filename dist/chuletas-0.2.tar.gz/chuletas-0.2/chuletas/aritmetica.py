#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def sumar(a, b):
    return a + b

def restar(a, b):
    return a - b

def mult(a, b):
    return a * b

def div(a, b):
    return a / b