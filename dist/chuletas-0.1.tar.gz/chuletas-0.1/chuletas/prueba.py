def prueba:
	print("esto es una prueba")
	
