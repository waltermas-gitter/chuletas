def prueba():
	x = "esto es una prueba"
	return x

	
